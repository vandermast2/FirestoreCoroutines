package com.breez.firestore.ui.base

import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity

abstract class BaseActivity<T: BaseVM> : AppCompatActivity(),BaseView,DeepLinkCallback {
    abstract val viewModelClass: Class<T>
    protected val viewModel: T by lazy(LazyThreadSafetyMode.NONE) { ViewModelProviders.of(this).get(viewModelClass) }
    protected abstract val layoutId: Int
    protected abstract val containerId: Int
    protected abstract val observeLiveData: T.() -> Unit

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layoutId)
        observeBaseLiveData()
    }

    override fun onResume() {
        super.onResume()
        with(viewModel.alertMessage) {
            value?.let {
                this@BaseActivity.showAlert(it)
                value = null
            }
        }
    }

    private fun observeBaseLiveData() = with(viewModel) {
        progressLiveData.observe(this@BaseActivity, Observer {
            it?.let { if (it) showProgress() else hideProgress() }
        })
        alertMessage.observe(this@BaseActivity, Observer {
            it?.let {
                this@BaseActivity.showAlert(it)
                alertMessage.value = null
            }
        })

        uriLiveData.observe(this@BaseActivity, Observer {
            it?.let {
                //                processDeepLink(it)
            }
        })
        observeLiveData()
    }

    //     It is specific of current project. All progress displaying now delegated to the fragments
    override fun showProgress() {
        // nothing
    }

    // It is specific of current project. All progress displaying now delegated to the fragments
    override fun hideProgress() {
        // nothing
    }

    override fun showAlert(text: String?) {
        val errorDialog = text.getNotEmptyOrNull()?.let { MessageDialog.newInstance(it) } ?: MessageDialog.newInstance()
        errorDialog.show(supportFragmentManager, MessageDialog::class.java.simpleName)
    }

}