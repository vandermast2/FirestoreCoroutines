package com.breez.firestore.ui.base

import android.arch.lifecycle.ViewModel

class BaseVM:ViewModel() {

}
