package com.breez.firestore.dataFlow

import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.QuerySnapshot

interface IDataManager {
    fun getAll(): Task<QuerySnapshot>
}
