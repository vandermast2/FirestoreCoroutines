package com.breez.firestore.ui

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.breez.firestore.AppApplication
import com.breez.firestore.R
import com.breez.firestore.dataFlow.IDataManager
import javax.inject.Inject


class MainActivity : AppCompatActivity() {
    @Inject
    lateinit var dataManger: IDataManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppApplication.component.inject(this)
        setContentView(R.layout.activity_main)

        dataManger.getAll().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                for (document in task.result!!) {
                    Log.d("TAG", document.id + " => " + document.data)
                }
            } else {
                Log.w("TAG", "Error getting documents.", task.exception)
            }
        }
//        FirebaseApp.initializeApp(this)
//        val db = FirebaseFirestore.getInstance()
        // Create a new user with a first and last name
//        val user = HashMap<String,Any>()
//        user.put("first", "Ada")
//        user.put("last", "Lovelace")
//        user.put("born", "1985")
//

//        val users = db.collection("users")
//            .get()
//            .addOnCompleteListener { task ->
//                if (task.isSuccessful) {
//                    for (document in task.result!!) {
//                        Log.d("TAG", document.id + " => " + document.data)
//                    }
//                } else {
//                    Log.w("TAG", "Error getting documents.", task.exception)
//                }
//            }
//
//// Add a new document with a generated ID
//        db.collection("users")
//            .add(user as Map<String, Any>)
//            .addOnSuccessListener { documentReference ->
//                Log.d("TAG",
//                    "DocumentSnapshot added with ID: " + documentReference.id
//                )
//            }
//            .addOnFailureListener { e -> Log.w("TAG", "Error adding document", e) }
    }
}
