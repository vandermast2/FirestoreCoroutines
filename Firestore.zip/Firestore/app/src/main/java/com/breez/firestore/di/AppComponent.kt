package com.breez.firestore.di

import com.breez.firestore.AppApplication
import com.breez.firestore.ui.MainActivity
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(modules = [(AppModule::class)])
interface AppComponent {
    fun inject(appApplication: AppApplication)
    fun inject(mainActivity: MainActivity)
}